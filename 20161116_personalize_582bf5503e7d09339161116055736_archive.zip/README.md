# WordPress Installer Boilerplate

WordPress Installer Boilerplate is intended to replace normal WordPress installation by providing a quicker installer. This install also comes with many commonly used plugins, both free and premium, pre-installed and pre-configured inside the newly installed WordPress.

## How To Install

1. **Create a new database**

  You can create a new database inside cPanel or phpMyAdmin. Use the usual way to create the database. Optionally you might want to create a database user and add the user into the database you just created.
  
  
2. **Upload the installation files**

   Upload the files to the directory where you want WordPress to be installed. The two files neccessary for the installation are the zip file with a long name, and installer.php. **Do not extract the zip file.**
   
   
3. **Install from browser**

   Open up your browser, and point the URL to the installer.php you just uploaded. This will open up the installation screen.
   
   * Insert the database name, database user and password (only if you created database user earlier, otherwise use the cPanel username/password). Check the connection, if it succeed, click next.
   * Replace the old URL to the new one, this should be inserted automatically by the installer. Confirm that they are correct and then click next.
   * Click file cleanup to remove all installation files. You will be directed to the admin login. You'll have to login with administrator access for the installation files to be removed. See below for admin username and password
   
## Account Credential

### Administrator Access
**Username:** firstcom<br>
**Password:** password

### Editor Access
**Username:** editor<br>
**Password:** password

Two accounts are automatically created once you have installed the boilerplate. The ‘firstcom’ account have administrator access and is able to change everything, including irrelevant portion or setting to something that might break the website. The username is not made as 'admin' for security purpose. ‘editor’ account have been tailor-made for client for the purpose of editing. It is able to edit all relevant contents and is easier to use. You can edit the 'editor' menu access and visibility by using Admin Menu Editor plugin, from Settings > Menu Editor Pro.

**Make sure to change the password for both accounts when installing the website live.**

## Pre-installed & Pre-configured Plugins

Make sure to thoroughly read and understand what each of the plugin does. You will need to remove all plugins unnecessary to your current project.

### CMS

1. **Advanced Custom Fields Pro (Premium - Updatable)**

   Allows you to create additional fields to pages or posts specific to the page template. Making content editing much easier. Go to Custom Fields for setting. Three field groups have been created; Options, Page - Home, and Page - Contact. Options allow you to call the custom field anywhere in the template, usually in a scenario where the content are repeated across pages, like contents inside header and footer. Page - Home and Page - Contact are specific to the Home and Contact template.
   
2. **Custom Post Type UI**

   Easily create new custom post types or taxonomies. Go to CPT UI for setting.
   
3. **TinyMCE Advanced**

   Enables advanced features and plugins in TinyMCE, the visual editor in WordPress.

### Development

1. **Duplicate Post**

   Duplicate any post or page by hovering the entry and clicking Clone.

2. **Duplicator**

   Allows you to migrate the site easily by creating an install package. This boilerplate is made by using Duplicator. It'll also automatically perform search and replace to mitigate chances of URL hardcoding still pointing back to your old site. This function only works on database values, which includes any field and custom field. However, it'll **NOT** work on your php template files. **DO NOT** hardcode any URL on your php template files.

3. **WPBakery Visual Composer (Premium)**

   Visual Composer is a handy tool to create a quick and easy layout inside your default text editor field. This will **ONLY** work on default text editor field. This plugin requres `body_class()` to be included inside `<body>` tag. If you are using Foundation framework, there is a slight conflict happening on the last Visual Composer column, which floats improperly. Open `foundation.css` and change `[class*="column"] + [class*="column"]:last-child` into `.column + .column:last-child, .columns + .columns:last-child` or you can safely remove the rule.

4. **Ultimate Addons for Visual Composer (Premium)**

   Includes Visual Composer premium addon elements like Icon, Info Box, Interactive Banner, Flip Box, Info List & Counter. Best of all - provides A Font Icon Manager allowing users to upload / delete custom icon fonts.

### Site Functions

1. **Contact Form 7**

   The most popular contact form plugin. One generic contact form have been created, and its shortcode have been inserted to Contact Us page.

2. **Contact Form 7 Honeypot**

   Add honeypot anti-spam functionality to the popular Contact Form 7 plugin. To use, add the honeypot tag anywhere in your contact form. It will not be visible on the front-end.

3. **Revolution Slider (Premium)**

   The most popular slider plugin. Global setting have been changed to include the script only on homepage for optimization. One slider have been created, and its shortcode have been inserted to Home page. This slider setting have also been changed to be more generic.
   
### Security

1. **iThemes Security**

   Almost all of the security setting have been turned on. This might interfere with certain plugin or functions of your website. Make sure to uncheck _Filter Non-English Characters_ on Security > Settings if your website is non-english.

### SEO

1. **WordPress SEO by Yoast**

### User Experience

1. **Admin Columns Pro + ACF add-on (Premium)**

   Allows you to edit columns in page list or any post type list. These columns can be made inline editable.

2. **Admin Menu Editor Pro (Premium - Updatable)**

   Allows you to rename menu, re-order menu or change menu visibility by account access.

## Live Checklist

1. **Duplicate the website with Duplicator**

   You can also do this after the third step if you want your development site to also be changed.
   
2. **Change the password for all account to a unique one**

   Make sure to use a strong password.
   
3. **Activate plugins**

   Security, and SEO plugins can be turned on and refreshed or configured.
   
4. **Check the live website for any error and if anything still links back to your development site**

   A good way to check this if your website is password-protected is to open an incognito window or a different browser and browse through the website. If a password notification pops up then a hardcoded URL is not converted.